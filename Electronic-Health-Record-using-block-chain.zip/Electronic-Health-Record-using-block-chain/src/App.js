
import './App.css';
import Healthcare from './Healthcare';

function App() {
  return (
    <div className="App">
      <Healthcare/>
    </div>
  );
}

export default App;
